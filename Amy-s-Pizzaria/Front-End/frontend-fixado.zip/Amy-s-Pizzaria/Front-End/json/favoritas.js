export default {
    "favoritas":[
       {
          "nome":"Calabresa",
          "ingrediente":"Calabresa, cebola e azeitonas roxas",
          "foto":"calabresa.png"
       },
       {
          "nome":"Mussarela",
          "ingrediente":"Mussarela com molho de tomate",
          "foto":"mussarela.png"
       },
       {
          "nome":"Frango Catupiry",
          "ingrediente":"Frango desfiado coberto com catupiry",
         "foto":"catupiry.png"
       },
       {
          "nome":"Morango com chocolate",
          "ingrediente":"Morango coberto com chocolate",
          "foto":"morango.png"
       }
       
    ]
 }

 