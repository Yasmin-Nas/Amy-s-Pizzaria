export default {
    "doces":[
        {
            "id": 16,
            "nome": "Morango com chocolate",
            "acompanhamentos": "Chocolate coberto com morango."
        },
        {
            "id": 15,
            "nome": "Romeu e Julieta",
            "acompanhamentos": "Goiabada com mussarela ou catupiry."
        },
        {
            "id": 14,
            "nome": "Prestígio",
            "acompanhamentos": "Brigadeiro tradicional e coco ralado."
        },
        {
            "id": 13,
            "nome": "Beijinho",
            "acompanhamentos": "Mussarela, leite condensado, coco e chocolate branco."
        },
        {
            "id": 12,
            "nome": "Banana",
            "acompanhamentos": "Banana, açúcar com canela, flambado com rum e licor de cassis."
        }
    ]
}