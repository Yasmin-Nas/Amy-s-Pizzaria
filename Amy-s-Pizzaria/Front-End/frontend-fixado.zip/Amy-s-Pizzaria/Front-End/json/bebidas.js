export default  {
    "bebidas": [
        {
            "id": 32,
            "nome": "Caipirinha abacaxi",
            "preco": "14,00"
        },
        {
            "id": 31,
            "nome": "Caipirinha morango",
            "preco": "14,00"
        },
        {
            "id": 30,
            "nome": "Caipirinha kiwi",
            "preco": "14,00"
        },
        {
            "id": 29,
            "nome": "Caipirinha limão",
            "preco": "14,00"
        },
        {
            "id": 28,
            "nome": "Brahma",
            "preco": "4,35"
        },
        {
            "id": 27,
            "nome": "Skol",
            "preco": "4,35"
        },
        {
            "id": 26,
            "nome": "Heineken",
            "preco": "5,00"
        },
        {
            "id": 25,
            "nome": "Heineken",
            "preco": "9,80"
        },
        {
            "id": 24,
            "nome": "Brahma",
            "preco": "9,00"
        },
        {
            "id": 23,
            "nome": "Skol",
            "preco": "9,00"
        },
        {
            "id": 22,
            "nome": "Água sem gás",
            "preco": "4,50"
        },
        {
            "id": 21,
            "nome": "Água com gás",
            "preco": "4,50"
        },
        {
            "id": 20,
            "nome": "Suco Limão",
            "preco": "9,00"
        },
        {
            "id": 19,
            "nome": "Suco Maracujá",
            "preco": "9,00"
        },
        {
            "id": 18,
            "nome": "Suco Abacaxi",
            "preco": "9,00"
        },
        {
            "id": 17,
            "nome": "Suco Laranja",
            "preco": "9,00"
        },
        {
            "id": 16,
            "nome": "H20 limoneto",
            "preco": "7,00"
        },
        {
            "id": 15,
            "nome": "H20 limão e laranja",
            "preco": "7,00"
        },
        {
            "id": 14,
            "nome": "H20 limão e maça",
            "preco": "7,00"
        },
        {
            "id": 13,
            "nome": "H20 limão",
            "preco": "7,00"
        },
        {
            "id": 12,
            "nome": "Soda",
            "preco": "11,00"
        },
        {
            "id": 11,
            "nome": "Pepsi",
            "preco": "12,00"
        },
        {
            "id": 10,
            "nome": "Sukita Laranja",
            "preco": "10,00"
        },
        {
            "id": 9,
            "nome": "Guaraná",
            "preco": "10,00"
        },
        {
            "id": 8,
            "nome": "Guaraná",
            "preco": "9,00"
        },
        {
            "id": 7,
            "nome": "Coca Cola",
            "preco": "11,00"
        },
        {
            "id": 6,
            "nome": "Fanta Laranja",
            "preco": "9,00"
        },
        {
            "id": 5,
            "nome": "Fanta Laranja",
            "preco": "6,00"
        },
        {
            "id": 4,
            "nome": "Guaraná",
            "preco": "6,00"
        },
        {
            "id": 3,
            "nome": "Coca-Cola Zero",
            "preco": "7,00"
        },
        {
            "id": 2,
            "nome": "Coca-Cola",
            "preco": "7,00"
        },
        {
            "id": 1,
            "nome": "Sprite",
            "preco": "6,00"
        }
        ]
        }