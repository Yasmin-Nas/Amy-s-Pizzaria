export default {
    "ingredientes": [
        {
            "id": 11,
            "nome": "Pepperoni",
            "acompanhamentos": "Queji, oregano e pepperoni."
        },
        {
            "id": 10,
            "nome": "Portuguesa",
            "acompanhamentos": "Queijo, presunto, ovo de codorna, azeitona preta, cebola, oregano e pimentão verde."
        },
        {
            "id": 9,
            "nome": "Bauru",
            "acompanhamentos": "Queijo, presunto, requijão, oregano e tomate."
        },
        {
            "id": 8,
            "nome": "Calabresa",
            "acompanhamentos": "Calabresa, cebola e azeitonas roxas"
        },
        {
            "id": 7,
            "nome": "Frango com Catupiry",
            "acompanhamentos": "Frango desfiado coberto com catupiry"
        },
        {
            "id": 6,
            "nome": "Marguerita",
            "acompanhamentos": "Molho de tomate, muçarela, parmesão e manjericão."
        },
        {
            "id": 5,
            "nome": "Siciliana",
            "acompanhamentos": "Molho de tomate, calabresa, champignon, mussarela e orégano."
        },
        {
            "id": 4,
            "nome": "Quatro Queijos",
            "acompanhamentos": "Molho de tomate, mussarela, provolone, catupiry, parmesão e orégano."
        },
        {
            "id": 3,
            "nome": "Toscana",
            "acompanhamentos": "Molho de Tomate, calabresa, mussarela, vinagre e orégano"
        },
        {
            "id": 2,
            "nome": "Atum",
            "acompanhamentos": "Molho de tomate, muçarela, atum sólido, cebola roxa e orégano."
        },
        {
            "id": 1,
            "nome": "Mussarela",
            "acompanhamentos": "Queijo e Tomate"
        }

    ]
 }

