export default {
    "promocoes": [
        {
            "id": 5,
            "prazo": "2023-01-01T00:00:00.000Z",
            "nome-pro": "Pague duas, leve três",
            "descricao": "Na compra de duas pizzas salgadas, ganhe uma doce."
        },
        {
            "id": 4,
            "prazo": "2023-01-01T00:00:00.000Z",
            "nome": "Desconto na primeira conta",
            "descricao": "Ganhe 10% de desconto na sua primeira compra."
        },
        {
            "id": 3,
            "prazo": "2023-01-01T00:00:00.000Z",
            "nome-pro": "Duas pizzas e Refrigerante",
            "descricao": "Na compra de uma pizza salgada e uma doce, ganhe um refrigerante dois litros."
        },
        {
            "id": 2,
            "prazo": "2023-01-01T00:00:00.000Z",
            "nome-pro": "Frete Grátis",
            "descricao": "Em compras acima de R$85,00, ganhe frete grátis"
        }
    ]
}